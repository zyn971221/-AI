package baidu.demo.token;

/**
 * Created by IntelliJ IDEA 2020.2.3 x64.
 *
 * @Author hcl
 * @create 2020/11/25 18:54
 * <version> sience 1.0.0
 */
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baidu.ai.aip.utils.HttpUtil;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 获取token类
 * @author hcl
 */
@Component
public  class Search implements ApplicationRunner {

    /**
     * 获取权限token
     */
    public static String access_token;
    @Override
    public void run(ApplicationArguments args) {

        // 官网获取的 API Key
        String clientId = "3hHKWafmyKCOQ48I1pSiXFnG";
        // 官网获取的 Secret Key
        String clientSecret = "cKtEOucmIEqenPMAtd84IrG9uHvmST5C";
        access_token= getAuth(clientId, clientSecret);
        System.out.println("人脸搜索的access_token:"+access_token);
        String data = faceDetect();
        System.out.println("人脸搜索返回的数据:"+data);
    }

    public static void main(String[] args) {
        // 官网获取的 API Key
        String clientId = "3hHKWafmyKCOQ48I1pSiXFnG";
        // 官网获取的 Secret Key
        String clientSecret = "cKtEOucmIEqenPMAtd84IrG9uHvmST5C";
        access_token= getAuth(clientId, clientSecret);
        System.out.println("人脸搜索的access_token:"+access_token);
        String data = faceDetect();
        System.out.println(data);
    }

    public static String getAuth(String ak, String sk) {
        // 获取token地址
        String authHost = "https://aip.baidubce.com/oauth/2.0/token?";
        String getAccessTokenUrl = authHost
                // 1. grant_type为固定参数
                + "grant_type=client_credentials"
                // 2. 官网获取的 API Key
                + "&client_id=" + ak
                // 3. 官网获取的 Secret Key
                + "&client_secret=" + sk;
        System.out.println("人脸搜索url:"+getAccessTokenUrl);
        try {
            URL realUrl = new URL(getAccessTokenUrl);
            // 打开和URL之间的连接
            HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : map.keySet()) {
                System.err.println(key + "--->" + map.get(key));
            }
            // 定义 BufferedReader输入流来读取URL的响应
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String result = "";
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
            /**
             * 返回结果示例
             */
            System.err.println("result:" + result);
            System.out.println("人脸搜索："+result);
            JSONObject jsonObject = JSON.parseObject(result);
            return jsonObject.getString("access_token");
        } catch (Exception e) {
            System.err.printf("获取token失败！");
            e.printStackTrace(System.err);
            return null;
        }

    }

    public static String faceDetect() {
        // 请求url
        String url = "https://aip.baidubce.com/rest/2.0/face/v3/search";
        try {
//            JSONArray param =new JSONArray();
//            JSONObject jsonObject = new JSONObject(new LinkedHashMap<>());
//            Map<String, Object> map = new HashMap<>();
//            jsonObject.put("image", "https://pic.sogou.com/d?query=%E4%BA%BA%E8%84%B8%E5%9B%BE%E7%89%87%20%E4%BA%BA%E8%84%B8%E8%AF%86%E5%88%AB&forbidqc=&entityid=&preQuery=&rawQuery=%E4%BA%BA%E8%84%B8%E5%9B%BE%E7%89%87&queryList=&st=255&mode=255&did=5");
//            jsonObject.put("image_type", "URL");
//            param.add(jsonObject);
            Map<String, Object> map = new HashMap<>();
            map.put("image","https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1606388020364&di=c4684a56ed139e4516f0831fee238798&imgtype=0&src=http%3A%2F%2Fimages.ofweek.com%2FUpload%2FNews%2F2016-11%2Fsmarthome%2F1102%2F26.png");
            //map.put("face_field", "faceshape,facetype");
            map.put("image_type", "URL");
            map.put("group_id_list", "1");

            String param = GsonUtils.toJson(map);
            System.out.println(param);

            // 注意这里仅为了简化编码每一次请求都去获取access_token，线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
            String accessToken = access_token;

            String result = HttpUtil.post(url, accessToken, "application/json",param);

            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }



}