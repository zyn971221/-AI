package baidu.demo.utils;

/**
 * Created by IntelliJ IDEA 2020.2.3 x64.
 *
 * @Author zyn521
 * @create 2020/11/26 14:43
 * <version> sience 1.0.0
 */
public class detect {
}
